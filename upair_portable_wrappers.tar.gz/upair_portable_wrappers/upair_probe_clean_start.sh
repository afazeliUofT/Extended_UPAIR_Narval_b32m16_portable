#!/usr/bin/env bash
# Probe that the repository is clean/minimal and the portable venv is usable before Stage A.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
source "${ROOT}/upair_portable_env.sh"
cd "${UPAIR_REPO_ROOT}"

fail=0
check_ok() { echo "[OK] $*"; }
check_fail() { echo "[FAIL] $*" >&2; fail=1; }

[[ "${UPAIR_VENV_PATH}" == "${UPAIR_REPO_PARENT}/.vevn_upair_potable" ]] \
  && check_ok "venv path is one level above repo: ${UPAIR_VENV_PATH}" \
  || check_fail "venv path is not the requested parent/.vevn_upair_potable: ${UPAIR_VENV_PATH}"

for item in src scripts configs pyproject.toml requirements.txt; do
  [[ -e "${item}" ]] && check_ok "required item exists: ${item}" || check_fail "missing required item: ${item}"
done
[[ -f requirements-narval.txt ]] && check_ok "requirements-narval.txt exists" || echo "[WARN] requirements-narval.txt missing; requirements.txt will be used"

for script in \
  upair_portable_env.sh \
  upair_make_minimal_scratch.sh \
  upair_submit_stageA_all.sh \
  upair_submit_stageB_all.sh \
  upair_submit_train_eval_all.sh \
  upair_probe_clean_start.sh \
  upair_probe_after_stageB.sh \
  upair_probe_after_train_eval.sh; do
  [[ -x "${script}" ]] && check_ok "wrapper executable: ${script}" || check_fail "wrapper missing/not executable: ${script}"
done

if [[ -e TWC_plots_comprehensive ]]; then
  check_fail "old training/evaluation output folder still exists: TWC_plots_comprehensive"
else
  check_ok "no old TWC_plots_comprehensive output folder"
fi

if [[ -d optuna ]] && find optuna -mindepth 1 -maxdepth 3 -type f | grep -q .; then
  check_fail "optuna/ is not empty before a from-scratch Stage A"
else
  check_ok "optuna/ is empty before Stage A"
fi

old_files=$(find . -maxdepth 2 -type f \( \
  -name '*stageB_locked*best_params.json' -o \
  -name '*.db' -o \
  -name 'best.weights.h5' -o \
  -name '*.out' -o \
  -name '*.err' -o \
  -name '*.log' -o \
  -name 'README_CLEAN_OPTUNA*.md' -o \
  -name 'README_NARVAL*.md' -o \
  -name 'PORTABLE_README.md' \
\) -print)
if [[ -n "${old_files}" ]]; then
  echo "${old_files}" >&2
  check_fail "old evidence/readme/log files still found above"
else
  check_ok "no old Stage-B-locked JSON, DB, weight, log, or old README evidence at shallow depth"
fi

upair_ensure_venv
python -m compileall -q src scripts
check_ok "Python syntax compile passed for src/ and scripts/"

python "${UPAIR_REPO_ROOT}/scripts/run_optuna_1dmrs_structure_isolated.py" --help >/dev/null
check_ok "Optuna entry point help works"
python "${UPAIR_REPO_ROOT}/scripts/run_comprehensive_mu32_ablation.py" --help >/dev/null
check_ok "train/eval entry point help works"

grep -q -- '--require-optuna-best' upair_submit_train_eval_all.sh \
  && check_ok "train/eval wrapper requires external Optuna best parameters" \
  || check_fail "train/eval wrapper does not force --require-optuna-best"

grep -q 'clean_b32_iso_u34610_1dmrs_stageB' upair_submit_train_eval_all.sh \
  && check_ok "train/eval wrapper is wired to Stage-B prefix" \
  || check_fail "train/eval wrapper is not wired to Stage-B prefix"

if [[ "${fail}" != "0" ]]; then
  echo "[PROBE] FAILED clean-start probe" >&2
  exit 1
fi

echo "[PROBE] PASSED clean-start portability probe"
